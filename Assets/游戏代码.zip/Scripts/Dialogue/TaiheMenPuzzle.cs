using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaiheMenPuzzle : MonoBehaviour
{
    void Start()
    {
        //��ʼ������濪ʼ�Ի�
        CraftingSystem.Instance.CraftItem("taihe_gate_material");
    }
}
