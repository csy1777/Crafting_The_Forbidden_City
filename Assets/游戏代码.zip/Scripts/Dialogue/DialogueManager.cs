using System.Collections;
using UnityEngine;
using UnityEngine.UI; 

public class DialogueManager : MonoBehaviour
{
    public static DialogueManager Instance;

    [Header("UI ����")]
    public GameObject dialoguePanel;   
    public Text dialogueText;          

    [Header("ͷ������")]
    public Image leftAvatar;   
    public Image rightAvatar;  
    public Sprite elderSprite; 
    public Sprite youthSprite; 

    [Header("�����ٶ�")]
    public float typingSpeed = 0.05f;  // ÿ���ַ��������

    private string[] currentLines;     // ��ǰ�Ի������о���
    private int currentLineIndex;      // ��ǰ��ʾ���ڼ���
    private bool isTyping;             // �Ƿ����ڴ���
    private Coroutine typingCoroutine;

    void Awake()
    {
        
        if (Instance == null)
        {
            Instance = this;
        
        }
        else
        {
            Destroy(gameObject);
        }

        // ��ʼ���ضԻ���
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);
    }

    void Update()
    {
        // ���ڶԻ��򼤻�ʱ�����������������
        if (dialoguePanel.activeSelf && Input.anyKeyDown)
        {
            HandleNextLine();
        }
    }

    /// <summary>
    /// ͨ���ַ������鿪ʼ�Ի�
    /// </summary>
    public void StartDialogue(string[] lines)
    {
        if (lines == null || lines.Length == 0) return;
        currentLines = lines;
        currentLineIndex = 0;
        dialoguePanel.SetActive(true);
        ShowCurrentLine();
    }

   
    private void ShowCurrentLine()
    {
        if (currentLineIndex < currentLines.Length)
        {
            string rawText = currentLines[currentLineIndex];
            string speaker;
            string displayText = ParseSpeaker(rawText, out speaker);

            // ����˵��������ͷ��
            if (speaker == "elder")
            {
                leftAvatar.sprite = elderSprite;
                leftAvatar.gameObject.SetActive(true);
                rightAvatar.gameObject.SetActive(false);
            }
            else if (speaker == "youth")
            {
                rightAvatar.sprite = youthSprite;
                rightAvatar.gameObject.SetActive(true);
                leftAvatar.gameObject.SetActive(false);
            }
            else
            {
                // û�б�ʶ������������ͷ��
                leftAvatar.gameObject.SetActive(false);
                rightAvatar.gameObject.SetActive(false);
            }

            if (typingCoroutine != null)
                StopCoroutine(typingCoroutine);
            typingCoroutine = StartCoroutine(TypeText(displayText));
        }
        else
        {
            EndDialogue();
        }
    }

    // ���ִ�ӡЭ��
    private IEnumerator TypeText(string text)
    {
        isTyping = true;
        dialogueText.text = "";
        foreach (char c in text)
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(typingSpeed);
        }
        isTyping = false;
        typingCoroutine = null;
    }

   
    private void HandleNextLine()
    {
        if (isTyping)
        {
            if (typingCoroutine != null)
                StopCoroutine(typingCoroutine);
            string rawText = currentLines[currentLineIndex];
            string speaker;
            string displayText = ParseSpeaker(rawText, out speaker);
            dialogueText.text = displayText;
            isTyping = false;
            typingCoroutine = null;
        }
        else
        {
            currentLineIndex++;
            ShowCurrentLine();
        }
    }



    // ����˵���߱�ʶ�����ش��ı�
    private string ParseSpeaker(string rawText, out string speaker)
    {
        speaker = "";
        if (rawText.StartsWith("[����]"))
        {
            speaker = "elder";
            return rawText.Substring(4); // ȥ�� "[����]" 
        }
        else if (rawText.StartsWith("[����]"))
        {
            speaker = "youth";
            return rawText.Substring(4);
        }
        return rawText;
    }

    // �����Ի�
    private void EndDialogue()
    {
        dialoguePanel.SetActive(false);
        currentLines = null;
        currentLineIndex = 0;
        isTyping = false;
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);
    }
}