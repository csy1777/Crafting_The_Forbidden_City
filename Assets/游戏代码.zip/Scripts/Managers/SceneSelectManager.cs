using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneSelectManager : MonoBehaviour
{
    [Header("������ťImage����")]
    public Image taiheGateImage;     
    public Image taiheHallImage;     
    public Image zhongheHallImage;   
    public Image baoheHallImage;    

    [Header("��ť����")]
    public Button taiheGateButton;     
    public Button taiheHallButton;    
    public Button zhongheHallButton;  
    public Button baoheHallButton;     

    [Header("��ɫ����")]
    public Color completedColor = Color.green;   // ��ɺ���ɫ
    public Color lockedColor = Color.gray;       // δ������ɫ
    public Color unlockedColor = Color.white;    // �ѽ�����δ�����ɫ

    void Start()
    {
        // ��ʼ������Image��ɫ
        LoadProgressAndUpdateImages();
    }

    void LoadProgressAndUpdateImages()
    {
        if (GameProgressManager.Instance == null)
        {
            Debug.LogError("GameProgressManagerδ�ҵ���");
            return;
        }

        if (taiheGateImage != null)
        {
            bool isCompleted = GameProgressManager.Instance.IsPuzzleCompleted("TaiheMenPuzzleScene");
            taiheGateImage.color = isCompleted ? completedColor : unlockedColor;

            if (taiheGateButton != null)
                taiheGateButton.interactable = true; // ̫�������ǿɵ��
        }

        if (taiheHallImage != null)
        {
            bool isCompleted = GameProgressManager.Instance.IsPuzzleCompleted("TaihePuzzleScene");
            bool isTaiheGateCompleted = GameProgressManager.Instance.IsPuzzleCompleted("TaiheMenPuzzleScene");

            taiheHallImage.color = isCompleted ? completedColor : (isTaiheGateCompleted ? unlockedColor : lockedColor);

            if (taiheHallButton != null)
                taiheHallButton.interactable = isTaiheGateCompleted || isCompleted;
        }

        if (zhongheHallImage != null)
        {
            bool isCompleted = GameProgressManager.Instance.IsPuzzleCompleted("ZhonghePuzzleScene");
            bool isTaiheHallCompleted = GameProgressManager.Instance.IsPuzzleCompleted("TaihePuzzleScene");

            zhongheHallImage.color = isCompleted ? completedColor : (isTaiheHallCompleted ? unlockedColor : lockedColor);

            if (zhongheHallButton != null)
                zhongheHallButton.interactable = isTaiheHallCompleted || isCompleted;
        }

        if (baoheHallImage != null)
        {
            bool isCompleted = GameProgressManager.Instance.IsPuzzleCompleted("BaohePuzzleScene");
            bool isZhongheCompleted = GameProgressManager.Instance.IsPuzzleCompleted("ZhonghePuzzleScene");

            baoheHallImage.color = isCompleted ? completedColor : (isZhongheCompleted ? unlockedColor : lockedColor);

            if (baoheHallButton != null)
                baoheHallButton.interactable = isZhongheCompleted || isCompleted;
        }
    }

    //public void ResetAllProgress()
    //{
    //    if (GameProgressManager.Instance != null)
    //    {
    //        GameProgressManager.Instance.ResetAllProgress();
    //        LoadProgressAndUpdateImages();
    //        Debug.Log("���н���������");
    //    }
    //}
}