using UnityEngine;
using UnityEngine.UI;

public class ResetButtonHandler : MonoBehaviour
{
    void Start()
    {
        Button btn = GetComponent<Button>();
        if (btn != null)
        {
            // ���ӵ���¼�
            btn.onClick.AddListener(OnResetButtonClick);
        }
    }

    void OnResetButtonClick()
    {
        if (GameProgressManager.Instance != null)
        {
            GameProgressManager.Instance.ResetAllProgress();
            Debug.Log("��Ϸ����������");
            SceneSelectManager sceneSelect = FindObjectOfType<SceneSelectManager>();
            if (sceneSelect != null)
            {
                // ���¼��س�����ˢ��
                UnityEngine.SceneManagement.SceneManager.LoadScene(
                    UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
                );
            }
        }
        else
        {
            Debug.LogError("GameProgressManagerδ�ҵ���");
        }
    }
}